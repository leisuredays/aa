// 瞬きで目を閉じている時間(sec)
export const BLINK_CLOSE_MAX = 0.12;
// 瞬きで目を開いている時間(sec)
export const BLINK_OPEN_MAX = 5;
