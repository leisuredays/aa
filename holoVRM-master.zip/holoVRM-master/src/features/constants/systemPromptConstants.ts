export const SYSTEM_PROMPT = `여기에는 홀로라이브 멤버를 선택하면 자동으로 생성됩니다.

또한, 대화하고싶은 홀로라이브 멤버가 추가로 필요하신데 홀로라이브 mmd를 구할 수 있는 상황이면 문의 부탁드립니다.

email: holovrm@gmail.com`;


