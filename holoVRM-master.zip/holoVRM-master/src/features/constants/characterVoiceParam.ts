export type CharacterVoiceParam = {
    voiceId: string;
};

export const DEFAULT_CHARACTER_VOICE_PARAM: CharacterVoiceParam = {
    voiceId: "MF3mGyEYCl7XYWbV9V6O", // Elli
} as const;