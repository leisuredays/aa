export interface LipSyncAnalyzeResult {
  volume: number;
}
