export interface VRMAnimationLoaderPluginOptions {
}
